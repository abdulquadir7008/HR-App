<?php include("config.php");
echo session_id();
echo $_SESSION['id'];
?>