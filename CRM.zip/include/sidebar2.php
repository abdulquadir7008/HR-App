<div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div class="sidebar-menu">
						<ul>
							<li> 
								<a href="index.php"><i class="la la-home"></i> <span>Back to Home</span></a>
							</li>
							<li class="menu-title">Settings</li>
							<li class="<?php if($pagesetting == 'settings.php'){ echo "active";}?>"> 
								<a href="settings.php"><i class="la la-building"></i> <span>Company Settings</span></a>
							</li>
							<!--li> 
								<a href="localization.html"><i class="la la-clock-o"></i> <span>Localization</span></a>
							</li-->
							
							<li class="<?php if($pagesetting == 'roles-permissions.php'){ echo "active";}?>"> 
								<a href="roles-permissions.php"><i class="la la-key"></i> <span>Roles & Permissions</span></a>
							</li>
							<!--li> 
								<a href="email-settings.html"><i class="la la-at"></i> <span>Email Settings</span></a>
							</li-->
							<!--li> 
                                <a href="performance-setting.html"><i class="la la-chart-bar"></i> <span>Performance Settings</span></a>
                            </li-->
                            <!--li> 
                                <a href="approval-setting.html"><i class="la la-thumbs-up"></i> <span>Approval Settings</span></a>
                            </li-->
							<li> 
								<a href="invoice-settings.php"><i class="la la-pencil-square"></i> <span>Invoice Settings</span></a>
							</li>
							<!--li> 
								<a href="salary-settings.html"><i class="la la-money"></i> <span>Salary Settings</span></a>
							</li-->
							<!--li> 
								<a href="notifications-settings.html"><i class="la la-globe"></i> <span>Notifications</span></a>
							</li-->
							<li class="<?php if($pagesetting == 'change-password.php'){ echo "active";}?>"> 
								<a href="change-password.php"><i class="la la-lock"></i> <span>Change Password</span></a>
							</li>
							<li> 
								<a href="leave-type.php"><i class="la la-cogs"></i> <span>Leave Type</span></a>
							</li>
							<!--li> 
								<a href="toxbox-setting.html"><i class="la la-comment"></i> <span>ToxBox Settings</span></a>
							</li>
							<li> 
								<a href="cron-setting.html"><i class="la la-rocket"></i> <span>Cron Settings</span></a>
							</li-->
						</ul>
					</div>
                </div>
            </div>